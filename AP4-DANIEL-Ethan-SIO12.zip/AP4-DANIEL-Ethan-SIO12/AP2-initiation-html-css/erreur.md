Voici tous les erreur corrigés:

#########################"Première erreurs"#########################
Sur le site tous les boutons qui ramenait sur chaque option :
Version avec erreurs: 
 <button><a href="html.html">En savoir plus</a></button>
version avec corrigé:
 <button><a href="pages/html.html">En savoir plus</a></button>


#########################"Dauxième erreurs" #########################